package Analizador;

public enum Token 
{
    reservada,
    litCar,
    litCad,
    id,
    num,
    numFlotante,
    menIgual,
    mayIgual,
    igual,
    dif,
    agrupacion,
    aritmetico,
    logico,
    relacional,
    salto,
    asignacion,
    finSentencia,
    puntos,
    coma,
    ERRORLCAD,
    ERRORLCAR,
    ERROR
}
